class View(object):
	def __init__(self, request, custom=None):
		self.request = request
		self.custom = custom
